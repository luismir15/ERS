create view user_join(id, username, password, firstname, lastname, email, role) as
SELECT ers_users.ers_user_id     AS id,
       ers_users.ers_username    AS username,
       ers_users.ers_password    AS password,
       ers_users.user_first_name AS firstname,
       ers_users.user_last_time  AS lastname,
       ers_users.user_email      AS email,
       eur.user_role             AS role
FROM ers_users
         JOIN ers_user_roles eur ON eur.ers_user_role_id = ers_users.user_role_id;

alter table user_join
    owner to luisrev;

