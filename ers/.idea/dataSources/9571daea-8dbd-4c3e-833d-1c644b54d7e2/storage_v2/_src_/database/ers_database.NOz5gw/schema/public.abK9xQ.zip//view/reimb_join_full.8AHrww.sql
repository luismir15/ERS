create view reimb_join_full (id, amount, submited, resolved, descriptio, author, resolver, statusid, status, type) as
SELECT r.reimb_id          AS id,
       r.reimb_amount      AS amount,
       r.reimb_submitted   AS submited,
       r.reimb_resolved    AS resolved,
       r.reimb_description AS descriptio,
       eua.ers_username    AS author,
       eur.ers_username    AS resolver,
       ers.reimb_status_id AS statusid,
       ers.reimb_status    AS status,
       ert.reimb_type      AS type
FROM ers_reimbursement r
         JOIN ers_users eua ON r.reimb_author = eua.ers_user_id
         LEFT JOIN ers_users eur ON r.reimb_resolver = eur.ers_user_id
         JOIN ers_reimbursement_status ers ON ers.reimb_status_id = r.reimb_status_id
         JOIN ers_reimbursement_type ert ON ert.reimb_type_id = r.reimb_type_id;

alter table reimb_join_full
    owner to luisrev;

