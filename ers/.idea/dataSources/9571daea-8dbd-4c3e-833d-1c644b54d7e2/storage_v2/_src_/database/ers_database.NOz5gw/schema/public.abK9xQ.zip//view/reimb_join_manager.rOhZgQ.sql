create view reimb_join_manager(id, amount, submited, resolved, descriptio, author, status, type) as
SELECT ers_reimbursement.reimb_id          AS id,
       ers_reimbursement.reimb_amount      AS amount,
       ers_reimbursement.reimb_submitted   AS submited,
       ers_reimbursement.reimb_resolved    AS resolved,
       ers_reimbursement.reimb_description AS descriptio,
       eu.ers_username                     AS author,
       ers.reimb_status                    AS status,
       et.reimb_type                       AS type
FROM ers_reimbursement
         JOIN ers_reimbursement_type et ON ers_reimbursement.reimb_type_id = et.reimb_type_id
         JOIN ers_reimbursement_status ers ON ers.reimb_status_id = ers_reimbursement.reimb_status_id
         JOIN ers_users eu ON ers_reimbursement.reimb_author = eu.ers_user_id;

alter table reimb_join_manager
    owner to luisrev;

